<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="The Hanger has made their services even more better, we are making our services more of a self-service and helping you do your shopping more conviniently.">
    <meta name="author" content="Richard">

    <!-- OG Meta Tags to improve the way the post looks when you share the page on LinkedIn, Facebook, Google+ -->
    <meta property="og:site_name" content="" /> <!-- website name -->
    <meta property="og:site" content="" /> <!-- website link -->
    <meta property="og:title" content=""/> <!-- title shown in the actual shared post -->
    <meta property="og:description" content="The Hanger has made their services even more better, we are making our services more of a self-service and helping you do your shopping more conviniently." /> <!-- description shown in the actual shared post -->
    <meta property="og:image" content="images/hangerlogo.JPG" /> <!-- image link, make sure it's jpg -->
    <meta property="og:url" content="https://thehangerug.com" /> <!-- where do you want your post to link to -->
    <meta name="twitter:card" content="summary_large_image"> <!-- to have large image post format in Twitter -->

    <!-- Webpage Title -->
    <title>The Hanger| Hanging and Unhanging made Easy</title>
    
    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,700&display=swap" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    
    <!-- Favicon  -->
    <link rel="icon" href="images/favicon.png">
</head>
<body>
    
    <!-- Header -->
    <header id="header" class="header">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text-container">
                        <h3 hidden="true">The Hanger annual Exchange Event!</h3>
                        <div class="countdown">
                            <span id="clock" hidden="true"></span>
                            <img src="images/thehangerlogo.png" width="300px" height="160px" alt="The Hanger Logo">
                        </div> <!-- end of countdown -->

                        <h1>Who we are!</h1>
                        <p class="p-large">The Hanger is an online resale platform catering to buyers and sellers since 2018. It is the first of its kind in Uganda and here is what makes it extraordinarily unique!<br>The Hanger has a pivotal concept to help people make money off items they have lying around at home, especially clothes.&nbsp;<a href="https://app.thehangerug.com/about/">Learn More</a></p>
                       <!--<div class="container">
                           <div class="img">
                            <img src="images/winnieb.png" class="img" width="150px" height="150px" align="Left" alt="Winnie" title="Winnie Begumisa">
                            <img src="images/amanda.jpg" class="img" width="150px" height="150px" align="right" alt="Amanda" title="Amanda Lisa">

                        </div>
                       </div>
                       <div>
                       <p align="Left"><span class="fa fa-hand-point-left" style="color: orange;"></span> Winnie Begumisa</p>
                       <p align="right"> Amanda Lisa Sselwanga <span class="fa fa-hand-point-right" style="color: orange;"></span></p>
                       </div>-->
                       


                    </div> <!-- end of text-container -->

                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->

        <!-- Social Links -->
        <div class="social-container">
            
            <!-- Text Logo - Use this if you don't have a graphic logo -->
            <!-- <a class="logo-text" href="index.html">The Hanger :)</a> -->

            <!-- Image Logo -->
            <h2>The Hanger<sup>&reg;</sup></h2>
            
            <span class="fa-stack">
                <a href="https://facebook.com/thehanger" target="_blank">
                    <i class="fas fa-circle fa-stack-2x"></i>
                    <i class="fab fa-facebook-f fa-stack-1x"></i>
                </a>
            </span>
            <span class="fa-stack">
                <a href="https://twitter.com/TheHanger___" target="_blank">
                    <i class="fas fa-circle fa-stack-2x"></i>
                    <i class="fab fa-twitter fa-stack-1x"></i>
                </a>
            </span>
            
            <span class="fa-stack">
                <a href="https://www.instagram.com/__thehanger_/" target="_blank">
                    <i class="fas fa-circle fa-stack-2x"></i>
                    <i class="fab fa-instagram fa-stack-1x"></i>
                </a>
            </span>
                <span class="fa-stack">
                <a href="https://www.instagram.com/__thehanger_/" target="_blank">
                    <i class="fas fa-circle fa-stack-2x"></i>
                    <i class="fab fa-snapchat fa-stack-1x"></i>
                </a>
            </span>
        </div> <!-- end of social-container -->
        <!-- end of social links --> 

    </header>
    <body>
        <div class="footer" align="center">
                <p>Copyright &copy;&nbsp;2021</p>
                
            </div>
    </body>


     <!-- end of header -->
    <!-- end of header -->


    <!-- Scripts -->
    <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
    <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="js/jquery.countdown.min.js"></script> <!-- The Final Countdown plugin for jQuery -->
    <script src="js/scripts.js"></script> <!-- Custom scripts -->
</body>
</html>