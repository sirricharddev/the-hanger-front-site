<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="The Hanger has made their services even more better, we are making our services more of a self-service and helping you do your shopping more conviniently.">
    <meta name="author" content="Richard">

    <!-- OG Meta Tags to improve the way the post looks when you share the page on LinkedIn, Facebook, Google+ -->
    <meta property="og:site_name" content="" /> <!-- website name -->
    <meta property="og:site" content="" /> <!-- website link -->
    <meta property="og:title" content=""/> <!-- title shown in the actual shared post -->
    <meta property="og:description" content="The Hanger has made their services even more better, we are making our services more of a self-service and helping you do your shopping more conviniently." /> <!-- description shown in the actual shared post -->
    <meta property="og:image" content="images/hangerlogo.JPG" /> <!-- image link, make sure it's jpg -->
    <meta property="og:url" content="" /> <!-- where do you want your post to link to -->
    <meta name="twitter:card" content="summary_large_image"> <!-- to have large image post format in Twitter -->

    <!-- Webpage Title -->
    <title>The Hanger| Hanging and Unhanging made Easy</title>
    
    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,700&display=swap" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    
    <!-- Favicon  -->
    <link rel="icon" href="images/favicon.png">
</head>
<body>
    
    <!-- Header -->
    <header id="header" class="header">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text-container">
                        <h3 hidden="true">The Hanger annual Exchange Event!</h3>
                        <div class="countdown">
                            <span id="clock" hidden="true"></span>
                            <img src="images/thehangerlogo.png" width="300px" height="160px" alt="The Hanger Logo">
                        </div> <!-- end of countdown -->

                        <h1>Welcome!</h1>
                        <p class="p-large">Are you looking to Hang/sell your items and get cash or Un-hang/buy from our affordable stock?<br>
                        We've got just the solution for you.<a href="about.php">Learn more</a></p>
                        <form>
                            <div class="signUpForm">
                                <a href="https://app.thehangerug.com/my-account/"><button class="btn-solid-reg" type="button">I want to Hang</button></a>
                                <span>&nbsp;</span>
                                <a href="https://app.thehangerug.com"><button class="btn-solid-reg" type="button">I want to UnHang</button></a>
                                
                                
                            </div>
                        </form>
                        
                        <!-- Sign Up Form 
                        <form id="signUpForm">
                            <div class="form-group">
                                <input type="email" class="form-control-input" id="semail" required>
                                <label class="label-control" for="semail">Email address</label>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="form-control-submit-button">SIGN UP</button>
                            </div>
                        </form>-->
                        <!-- end of sign up form -->

                    </div> <!-- end of text-container -->
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->

        <!-- Social Links -->
        <div class="social-container">
            
            <!-- Text Logo - Use this if you don't have a graphic logo -->
            <!-- <a class="logo-text" href="index.html">The Hanger :)</a> -->

            <!-- Image Logo -->
            <h2>The Hanger<sup>&reg;</sup></h2>
            
            <span class="fa-stack">
                <a href="https://facebook.com/thehanger" target="_blank">
                    <i class="fas fa-circle fa-stack-2x"></i>
                    <i class="fab fa-facebook-f fa-stack-1x"></i>
                </a>
            </span>
            <span class="fa-stack">
                <a href="https://twitter.com/TheHanger___" target="_blank">
                    <i class="fas fa-circle fa-stack-2x"></i>
                    <i class="fab fa-twitter fa-stack-1x"></i>
                </a>
            </span>
            
            <span class="fa-stack">
                <a href="https://www.instagram.com/__thehanger_/" target="_blank">
                    <i class="fas fa-circle fa-stack-2x"></i>
                    <i class="fab fa-instagram fa-stack-1x"></i>
                </a>
            </span>
                <span class="fa-stack">
                <a href="https://www.instagram.com/__thehanger_/" target="_blank">
                    <i class="fas fa-circle fa-stack-2x"></i>
                    <i class="fab fa-snapchat fa-stack-1x"></i>
                </a>
            </span>
        </div> <!-- end of social-container -->
        <!-- end of social links --> 
    </header>

    <body>
        <div class="footer" align="center">
                <p>Copyright &copy;&nbsp;2021</p>
                
            </div>
    </body>

     <!-- end of header -->
    <!-- end of header -->


    <!-- Scripts -->
    <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
    <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="js/jquery.countdown.min.js"></script> <!-- The Final Countdown plugin for jQuery -->
    <script src="js/scripts.js"></script> <!-- Custom scripts -->
</body>
</html>